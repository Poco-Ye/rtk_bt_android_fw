#ifndef _VND_BUILDCFG_H
#define _VND_BUILDCFG_H
#define BLUETOOTH_UART_DEVICE_PORT   "/dev/rtk_btusb"
#define BTVND_DBG   TRUE
#define LPM_SLEEP_MODE   FALSE
#endif
