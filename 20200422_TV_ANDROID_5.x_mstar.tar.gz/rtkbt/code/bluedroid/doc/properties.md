Properties
===
This document describes all of the Android properties used by bluedroid.

Please keep the following list in alphabetical order.

### TODO (Broadcom): write descriptions of what each property means and how
it's used.

* ``` debug.sys.noschedgroups ```
* ``` persist.service.bdroid.bdaddr ```
* ``` ro.bluetooth.hfp.ver ```
* ``` ro.bt.bdaddr_path ```
* ``` ro.product.model ```
* ``` service.brcm.bt.oob ```
