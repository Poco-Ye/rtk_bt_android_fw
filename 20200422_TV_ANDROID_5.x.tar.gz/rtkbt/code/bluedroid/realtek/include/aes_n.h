#ifndef _aes_128_h__
#define _aes_128_h__
void AES128_encrypt(unsigned char input[16], unsigned char key[16], unsigned char * output);
#endif
